import telebot
import json
import time
import threading
import os
from decimal import Decimal, ROUND_HALF_UP
from telebot import types

# ========== CONFIG ==========
TOKEN = "8307047195:AAGu-0bLJMKXZjDGZnuue_97WWaGZHz1-_E"
bot = telebot.TeleBot(TOKEN)
...
